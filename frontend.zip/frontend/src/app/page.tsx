// src/app/page.tsx
export default function RootPage() {
  return null; // Não renderiza nada, o middleware cuida do resto
}